

*** WARNING!! THIS FONT IS "FREE FOR PERSONAL USE ONLY" ***

If you love this font and want to use it for commercial purposes, please purchase the license here:
*** https://letterara.com/product/christmas-hearths-christmas-script-font/ ***

For any inquiries or custom license requests, feel free to contact me:
*** Email: thomasaradea@gmail.com | admin@letterara.com ***


------------------------------------------------------------


*** INDONESIA � MOHON DIBACA TERLEBIH DAHULU ***

Halo untuk agency, desainer, YouTuber, brand owner, atau siapa saja yang ingin menggunakan font ini untuk kepentingan komersial seperti:

- Konten media sosial yang dimonetisasi (YouTube, Instagram, Facebook, TikTok, Twitter, Spotify, Apple Music, dan platform lainnya)
- Video promosi, video iklan, intro/outro YouTube
- Poster film, pamflet, brosur, banner promosi
- Logo perusahaan atau brand
- Kaos, merchandise, dan produk sejenisnya
- Artwork untuk platform musik digital
- Desain untuk aplikasi, game, atau web interaktif
- dan lain lain

*** Silakan membeli lisensinya langsung kepada saya ***
Hubungi via Email:
*** thomasaradea@gmail.com | admin@letterara.com ***

Tenang, harga lisensi sangat bersahabat.


*** PERINGATAN ***
Menggunakan font ini hanya dengan lisensi "Personal Use" untuk keperluan komersial tanpa izin resmi dari kami, 
akan dikenakan biaya Corporate License. Menginstal font ini berarti Anda setuju dengan seluruh ketentuan lisensi.
